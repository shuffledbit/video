package example.pavan.com.video;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.VideoView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        Point size = new Point();
        getWindowManager().getDefaultDisplay().getSize(size);
        int screenWidth = size.x;
        int screenHeight = size.y;

        RelativeLayout r1 = findViewById(R.id.rl1);
        RelativeLayout r2 = findViewById(R.id.rl2);
        RelativeLayout r3 = findViewById(R.id.rl3);
        RelativeLayout r4 = findViewById(R.id.rl4);

        r1.getLayoutParams().width = screenWidth/2;
        r2.getLayoutParams().width = screenWidth/2;
        r3.getLayoutParams().width = screenWidth/2;
        r4.getLayoutParams().width = screenWidth/2;

        r1.getLayoutParams().height = screenHeight/2;
        r2.getLayoutParams().height = screenHeight/2;
        r3.getLayoutParams().height = screenHeight/2;
        r4.getLayoutParams().height = screenHeight/2;

        final VideoView v1 = findViewById(R.id.videoView1);
        final VideoView v2 = findViewById(R.id.videoView2);
        final VideoView v3 = findViewById(R.id.videoView3);
        final VideoView v4 = findViewById(R.id.videoView4);

        v1.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.v1));
        v2.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.v1));
        v3.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.v1));
        v4.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.v1));

        v1.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(final MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
                v1.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if(mp.isPlaying())
                            mp.pause();
                        else
                            mp.start();
                        return false;
                    }

                });
            }
        });
        v2.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public void onPrepared(final MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
                v2.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if(mp.isPlaying())
                            mp.pause();
                        else
                            mp.start();
                        return false;
                    }
                });
            }
        });


        v3.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(final MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
                v3.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if(mp.isPlaying())
                            mp.pause();
                        else
                            mp.start();
                        return false;
                    }
                });
            }
        });

        v4.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(final MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
                v4.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        if(mp.isPlaying())
                            mp.pause();
                        else
                            mp.start();
                        return false;
                    }
                });
            }
        });

    }

}
